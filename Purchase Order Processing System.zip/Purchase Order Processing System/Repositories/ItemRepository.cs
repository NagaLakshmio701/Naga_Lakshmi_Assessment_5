﻿using Purchase_Order_Processing_System.Entites;
using Microsoft.EntityFrameworkCore;


namespace Purchase_Order_Processing_System.Repositories
{
    public class ItemRepository:IItemRepository
    {

        private readonly PoDB1Context _context;

        public ItemRepository(PoDB1Context context)
        {
            _context = context;
        }
        public async Task<List<Item>> GetAll()
        {
            return await _context.Items.ToListAsync();
        }

        public async Task<Item> GetByITCode(string code)
        {
            return await _context.Items.SingleOrDefaultAsync(i => i.ITCode == code);
        }

        public async Task Add(Item item) 
        {
            await _context.Items.AddAsync(item);
            await _context.SaveChangesAsync();
        }

        public async Task Update(Item item) 
        {
            _context.Items.Update(item);
                await _context.SaveChangesAsync();
        }
        public async Task DeleteByITCode(string code)
        {
            var item= await _context.Items.FindAsync(code);
            _context.Items.Remove(item);
            await _context.SaveChangesAsync();
        }

    }
}
