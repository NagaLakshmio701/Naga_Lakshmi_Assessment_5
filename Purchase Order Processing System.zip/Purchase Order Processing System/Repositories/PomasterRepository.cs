﻿using Microsoft.EntityFrameworkCore;
using Purchase_Order_Processing_System.Entites;

namespace Purchase_Order_Processing_System.Repositories
{
    public class PomasterRepository:IPomasterRepository
    {
        private readonly PoDB1Context _context;

        public PomasterRepository(PoDB1Context context)
        {
            _context = context;
        }
        public async Task<List<Pomaster>> GetAll()
        {
            return await _context.Pomasters.ToListAsync();
        }

        public async Task<Pomaster> GetByPONO(string no)
        {
            return await _context.Pomasters.SingleOrDefaultAsync(s => s.PoNo == no);
        }

        public async Task Add(Pomaster pomaster) 
        {
            await _context.Pomasters.AddAsync(pomaster);
            await _context.SaveChangesAsync();
        }

        public async Task Update(Pomaster pomaster) 
        {
            _context.Pomasters.Update(pomaster);
            await _context.SaveChangesAsync();
        }
        public async Task DeleteByPONO(string no)
        {
            var pomaster = await _context.Pomasters.FindAsync(no);
            _context.Pomasters.Remove(pomaster);
            await _context.SaveChangesAsync();
        }

    }
}
