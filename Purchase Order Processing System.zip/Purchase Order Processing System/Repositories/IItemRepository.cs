﻿using Purchase_Order_Processing_System.Entites;

namespace Purchase_Order_Processing_System.Repositories
{
    public interface IItemRepository
    {
        Task<List<Item>> GetAll();
        Task<Item> GetByITCode(string code);
        Task Update(Item item);
        Task DeleteByITCode(string code);
        Task Add(Item item);
    }
}

