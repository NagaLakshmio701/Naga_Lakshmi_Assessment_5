﻿using Purchase_Order_Processing_System.Entites;

namespace Purchase_Order_Processing_System.Repositories
{
    public interface IPomasterRepository
    {

      


        Task<List<Pomaster>> GetAll();
        Task<Pomaster> GetByPONO(string no);
        Task Update(Pomaster pomaster);
        Task DeleteByPONO(string no);
        Task Add(Pomaster pomaster);
    }

}
