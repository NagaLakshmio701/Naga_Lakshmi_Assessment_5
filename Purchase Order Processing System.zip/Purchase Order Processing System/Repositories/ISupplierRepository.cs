﻿using Purchase_Order_Processing_System.Entites;

namespace Purchase_Order_Processing_System.Repositories
{
    public interface ISupplierRepository
    {
        Task<List<Supplier>> GetAll();
        Task<Supplier> GetByNo(string no);
        Task Update(Supplier supplier);
        Task DeleteByNo(string no);
        Task Add(Supplier supplier);

    }
}
