﻿using static Purchase_Order_Processing_System.Repositories.SupplierRepository;
using Purchase_Order_Processing_System.Entites;
using Microsoft.EntityFrameworkCore;


namespace Purchase_Order_Processing_System.Repositories
{
    public class SupplierRepository:ISupplierRepository
    {

      
            private readonly PoDB1Context _context;

            public SupplierRepository(PoDB1Context context)
            {
                _context = context;
            }
        public async Task<List<Supplier>> GetAll()
        {
            return await _context.Suppliers.ToListAsync();
        }

        public async Task<Supplier> GetByNo(string no)
        {
            return await _context.Suppliers.SingleOrDefaultAsync(s => s.SuplNo == no);
        }

        public async Task Add(Supplier supplier)
            {
                await _context.Suppliers.AddAsync(supplier);
                await _context.SaveChangesAsync();
            }

        public async Task Update(Supplier supplier)
        {
            _context.Suppliers.Update(supplier);
            await _context.SaveChangesAsync();
        }
        public async Task DeleteByNo(string no)
        {
                var supplier = await _context.Suppliers.FindAsync(no);
                _context.Suppliers.Remove(supplier);
                await _context.SaveChangesAsync();
            }

      
    }
    }

