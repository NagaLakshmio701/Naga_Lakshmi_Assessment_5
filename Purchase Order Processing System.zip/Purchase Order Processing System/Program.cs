
using Purchase_Order_Processing_System.Repositories;
using Purchase_Order_Processing_System.Entites;
using Purchase_Order_Processing_System.Migrations;
using Purchase_Order_Processing_System.Controllers;

namespace Purchase_Order_Processing_System
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);


            // Add services to the container.
            builder.Services.AddDbContext<PoDB1Context>();

            // Add services to the container.
            builder.Services.AddTransient<ISupplierRepository, SupplierRepository>();
            builder.Services.AddTransient<IItemRepository, ItemRepository>();

            builder.Services.AddTransient<IPomasterRepository, PomasterRepository>();



            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
