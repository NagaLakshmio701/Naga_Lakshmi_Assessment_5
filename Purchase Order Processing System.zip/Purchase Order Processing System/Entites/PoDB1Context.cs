﻿using Purchase_Order_Processing_System.Repositories;

using Microsoft.EntityFrameworkCore;

namespace Purchase_Order_Processing_System.Entites
{
    public class PoDB1Context : DbContext

    {
        private IConfiguration _configuration;

        public PoDB1Context(IConfiguration configuration)
        {
            _configuration = configuration;
        }


        //Entity Set
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<Pomaster> Pomasters { get; set; }



 


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_configuration.GetConnectionString("POMOConnection"));
        }

    }

}
