﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Purchase_Order_Processing_System.Entites
{
    public class Pomaster
    {

        [Key]
        [Column(TypeName = "char")]

        [StringLength(4)]
        public string PoNo { get; set; }

        [Column(TypeName="DateTime")]
        public DateTime PoDate { get; set; }
        [ForeignKey("Item")]
        [StringLength(4)]

        public char ITCode {  get; set; }

        [JsonIgnore]

        public Item? Item { get; set; }

        public int QTY {  get; set; }

        [ForeignKey("Supplier")]
        [StringLength(4)]

        public char SuplNo {  get; set; }
        [JsonIgnore]

        public Supplier? Supplier { get; set; }


    }
}
