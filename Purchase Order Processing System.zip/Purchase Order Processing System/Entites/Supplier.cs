﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Purchase_Order_Processing_System.Entites
{
    public class Supplier
    {
        [Key]
        [Column(TypeName ="char")]
        [StringLength(4)]
        [Required]

        public  string SuplNo { get; set; }

        [Column(TypeName ="varchar")]
        [StringLength(15)]
        [Required]
        public string SuplName { get;set;}


        [Column(TypeName = "varchar")]
        [StringLength(40)]
        [Required]


        public string SuplAddr { get;set;}
        
    }
}
