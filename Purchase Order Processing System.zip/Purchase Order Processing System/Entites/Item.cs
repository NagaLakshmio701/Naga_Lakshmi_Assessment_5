﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Purchase_Order_Processing_System.Entites
{
    public class Item
    {
        [Key]

        [Required]
        [Column(TypeName = "char")]

        [StringLength(4)]

        public string ITCode { get; set; }

        [Column(TypeName = "varchar")]
        [StringLength(15)]
        [Required]

        public string ITDesc {  get; set; }


        public int Money {  get; set; }
    }
}
