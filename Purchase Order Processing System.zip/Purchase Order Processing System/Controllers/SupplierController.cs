﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System.Entites;
using Purchase_Order_Processing_System.Repositories;

namespace Purchase_Order_Processing_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        private readonly ISupplierRepository _supplierRepository;

        public SupplierController(ISupplierRepository supplierRepository)
        {
            _supplierRepository = supplierRepository; 
        }

        [HttpGet, Route("GetAllSupplier")]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _supplierRepository.GetAll());
        }

        [HttpGet, Route("GetSupplierByNo")]

        public async Task<IActionResult> GetById(string no)
        {
            return Ok(await _supplierRepository.GetByNo(no));
        }

        [HttpPost, Route("AddSuppiler")]
        public async Task<IActionResult> Add(Supplier supplier) 
        {
            await _supplierRepository.Add(supplier);
                return Ok(supplier);
        }

        [HttpPut, Route("EditSupplier")]
        public async Task<IActionResult> Edit([FromBody] Supplier supplier) 
        {
            await _supplierRepository.Update(supplier);
            return StatusCode(200, supplier);
        }

        [HttpDelete, Route("DeleteSupplier")]
        public async Task<IActionResult> Delete(string no) { 

            await _supplierRepository.DeleteByNo(no);
            return Ok();
        }



    }
}
