﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System.Entites;
using Purchase_Order_Processing_System.Repositories;

namespace Purchase_Order_Processing_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PomasterController : ControllerBase
    {
        private readonly IPomasterRepository _pomasterRepository;

        public PomasterController(IPomasterRepository pomasterRepository)
        {
            _pomasterRepository = pomasterRepository;
        }

        [HttpGet, Route("GetAllPomasters")]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _pomasterRepository.GetAll());
        }

        [HttpGet, Route("GetPomasterByPONO")]

        public async Task<IActionResult> GetByPONO(string no)
        {
            return Ok(await _pomasterRepository.GetByPONO(no));
        }

        [HttpPost, Route("AddPomaster")]
        public async Task<IActionResult> Add(Pomaster pomaster) 
        {
            await _pomasterRepository.Add(pomaster);
            return Ok(pomaster);
        }

        [HttpPut, Route("Editpomaster")]
        public async Task<IActionResult> Edit([FromBody] Pomaster pomaster)
        {
            await _pomasterRepository.Update(pomaster);
            return StatusCode(200, pomaster);
        }

        [HttpDelete, Route("DeletePomaster")]
        public async Task<IActionResult> Delete(string no)
        {
            await _pomasterRepository.DeleteByPONO(no);
            return Ok(); 
        }



    }
}
