﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System.Entites;
using Purchase_Order_Processing_System.Repositories;

namespace Purchase_Order_Processing_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        private readonly IItemRepository _itemRepository;

        public ItemController(IItemRepository itemRepository)
        {
            _itemRepository = itemRepository;
        }

        [HttpGet, Route("GetAllItems")]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _itemRepository.GetAll());
        }

        [HttpGet, Route("GetItemByID")]

        public async Task<IActionResult> GetById(string  no)
        {
            return Ok(await _itemRepository.GetByITCode(no));
        }

        [HttpPost, Route("AddItem")]
        public async Task<IActionResult> Add(Item item) 
        {
            await _itemRepository.Add(item);
            return Ok(item);
        }

        [HttpPut, Route("EditItem")]
        public async Task<IActionResult> Edit([FromBody] Item item)
        {
            await _itemRepository.Update(item);
            return StatusCode(200, item);
        }

        [HttpDelete, Route("DeleteItem")]
        public async Task<IActionResult> DeleteItem(string no)

        {
                await _itemRepository.DeleteByITCode(no);
                return Ok();

            }
        }
    }



